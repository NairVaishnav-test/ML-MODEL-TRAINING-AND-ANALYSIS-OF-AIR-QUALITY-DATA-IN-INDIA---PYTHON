import streamlit as st
import pickle
import pandas as pd
import numpy as np

model=pickle.load(open("rf_model.pkl","rb"))
scaler=pickle.load(open("scaler.pkl","rb"))
features=pickle.load(open("features.pkl","rb"))
city_encoder=pickle.load(open("city_encode.pkl","rb"))

aqi_bucket_reverse_map = {
    0: "Severe",
    1: "Very Poor",
    2: "Poor",
    3: "Moderate",
    4: "Satisfactory",
    5: "Good"
}

st.title("AQI Prediction System")
st.write("Predict Air Quality Category using Machine Learning")

st.sidebar.header("Enter Pollutant Values")

input_data={}

city=st.sidebar.selectbox("Select City",city_encoder.classes_)

# To decode city column
input_data["City"]=city_encoder.transform([city])[0]

# For other features that are pollutants
for i in features:
    if i!= "City":
        input_data[i]=st.sidebar.number_input(
            i, min_value=0.0,value=0.0
        )

df=pd.DataFrame([input_data])

# Rearrange the order
df=df[features]

# Scaling the data
df= scaler.transform(df)


if st.button("Predict AQI Status"):
    prediction_encoded=model.predict(df)[0]
    predict_label=aqi_bucket_reverse_map[prediction_encoded]
    st.success(f"Predicted AQI Status for {city} is : {predict_label}")


